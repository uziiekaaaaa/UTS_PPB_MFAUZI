package com.example.aplikasi_catatan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
