import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'List Payment Toko Komputer',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: TransaksiScreen(),
    );
  }
}

class TransaksiScreen extends StatefulWidget {
  @override
  _TransaksiScreenState createState() => _TransaksiScreenState();
}

class _TransaksiScreenState extends State<TransaksiScreen> {
  // Daftar barang dan harga
  final List<Item> items = [
    Item(name: 'Laptop', price: 25000000),
    Item(name: 'Mouse', price: 120000),
    Item(name: 'Keyboard', price: 200000),
    Item(name: 'Monitor', price: 1500000),
    Item(name: 'Printer', price: 2200000),
  ];

  num totalBayar = 0;
  bool showStruk = false;

  // Reset all quantities and total
  void reset() {
    setState(() {
      for (var item in items) {
        item.qty = 0;
      }
      totalBayar = 0;
      showStruk = false;
    });
  }

  // Hitung total pembayaran
  void calculateTotal() {
    setState(() {
      totalBayar = items.fold(0, (total, item) => total + item.totalPrice);
    });
  }

  // Tampilkan struk setelah menghitung total
  void cetakStruk() {
    calculateTotal();
    setState(() {
      showStruk = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Toko Komputer'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            Expanded(child: buildItemList()),
            Divider(),
            buildActionButtons(),
            Divider(),
            if (showStruk) buildStruk(),
            Divider(),
            buildTotalBayar(),
          ],
        ),
      ),
    );
  }

  // Membuat list barang dan input jumlah
  Widget buildItemList() {
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return ListTile(
          title: Text(item.name),
          subtitle: Text('Harga: ${item.price}'),
          trailing: SizedBox(
            width: 50,
            child: TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(border: OutlineInputBorder()),
              onChanged: (value) {
                setState(() {
                  item.qty = int.tryParse(value) ?? 0;
                });
              },
            ),
          ),
        );
      },
    );
  }

  // reset dan cetak struk
  Widget buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ElevatedButton(
            onPressed: reset,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            child: Text('Reset'),
          ),
          ElevatedButton(
            onPressed: cetakStruk,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text('Cetak Struk'),
          ),
        ],
      ),
    );
  }

  // Menampilkan struk
  Widget buildStruk() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Struk Pembelian',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ...items.where((item) => item.qty > 0).map((item) {
            return ListTile(
              leading: Icon(Icons.shopping_cart),
              title: Text('${item.name} x ${item.qty}'),
              trailing: Text('${item.totalPrice}'),
            );
          }).toList(),
          Divider(),
          Text('Total: $totalBayar', style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  // Menampilkan total bayar
  Widget buildTotalBayar() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Total Bayar:',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          Text('$totalBayar',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

// Model item untuk menyimpan data barang
class Item {
  final String name;
  final num price;
  int qty;

  Item({required this.name, required this.price, this.qty = 0});

  // Total harga berdasarkan qty
  num get totalPrice => price * qty;
}
